<?php
// Realm Name, change "MY REALM NAME" with yours
$config['cfg_realmname'] = "MY REALM NAME";

// REALM ID Used for the realm you want to show check in database
$config['cfg_realmid'] = "3";

// Character DATABASE name 	| Default: characters
$config['cfg_chardb'] = "characters";

// Top Kill Streak MAX Results
$config['maxResults'] = "10";
?>