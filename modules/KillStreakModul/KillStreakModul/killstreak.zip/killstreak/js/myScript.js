var myScript = {
	sayHI: function()
	{
		alert('Say hi');
	}
};